import pygame
import random
pygame.init()

clock = pygame.time.Clock

music = pygame.mixer.music.load("Musicforsnake.mp3")
pygame.mixer.music.play(-1)

sirinaEkrana = 800
visinaEkrana = 780

win = pygame.display.set_mode((sirinaEkrana, visinaEkrana))
pygame.display.set_caption("Snake Game")

score = 0

x = 400
y = 390
width = 20
height = 20
vel = 10
snake_length = 1
snake_list = []

width2 = 10
height2 = 10
x2 = random.randint(20, 760)
y2 = random.randint(25, 740)

class snake(object):

    def __init__(self, x, y, width, height):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.vel = vel
        self.hitbox = (self.x, self.y, 20, 20)
        self.lenght = snake_length
        self.direction = 'RIGHT'

    def draw(self, win):
        pygame.draw.rect(win, "green", (self.x, self.y, self.width, self.height))
        self.hitbox = (self.x, self.y, 20, 20)
        # pygame.draw.rect(win, "orange", self.hitbox, 2)

class apple(object):
    def __init__(self, x2, y2, width2, height2):
        self.x2 = x2
        self.y2 = y2
        self.width2 = width2
        self.height2 = height2
        self.hitbox = (self.x2, self.y2, 10, 10)
        self.visible = True

    def draw(self, win):
        if self.visible:
            pygame.draw.rect(win, "red", (self.x2, self.y2, self.width2, self.height2))
            self.hitbox = (self.x2, self.y2, 10, 10)
            # pygame.draw.rect(win, "orange", self.hitbox, 2)

def redrawGameWindow():
    playerSnake.draw(win)
    thing.draw(win)

    text = font.render("Score: " + str(score), 1, "white")
    win.blit(text, (625, 10))

    pygame.display.update()

#MainLoop
direction = "RIGHT"
change_to = direction
font = pygame.font.SysFont("comicsans", 25, True)
fontOVER = pygame.font.SysFont("comicsans", 50, True)
textOVER = fontOVER.render("Game Over", 1, "red")
playerSnake = snake(400, 390, 25, 25)
thing = apple(x2, y2, 10, 10)
run = True
while run:
    pygame.time.delay(100)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False

    win.fill("black")

    keys = pygame.key.get_pressed()

    if keys[pygame.K_LEFT] and playerSnake.x - playerSnake.vel >= 0:
        playerSnake.x -= playerSnake.vel
        direction = "LEFT"
    if keys[pygame.K_RIGHT] and playerSnake.x + playerSnake.width + playerSnake.vel <= sirinaEkrana:
        playerSnake.x += playerSnake.vel
        direction = "RIGHT"
    if keys[pygame.K_UP] and playerSnake.y - playerSnake.vel >= 0:
        playerSnake.y -= playerSnake.vel
        direction = "UP"
    if keys[pygame.K_DOWN] and playerSnake.y + playerSnake.height + playerSnake.vel <= visinaEkrana:
        playerSnake.y += playerSnake.vel
        direction = "DOWN"

    if direction == 'UP':
        playerSnake.y -= 10
    if direction == 'DOWN':
        playerSnake.y += 10
    if direction == 'LEFT':
        playerSnake.x -= 10
    if direction == 'RIGHT':
        playerSnake.x += 10

    if keys[pygame.K_LEFT] and playerSnake.direction != 'RIGHT':
        playerSnake.direction = 'LEFT'
    if keys[pygame.K_RIGHT] and playerSnake.direction != 'LEFT':
        playerSnake.direction = 'RIGHT'
    if keys[pygame.K_UP] and playerSnake.direction != 'DOWN':
        playerSnake.direction = 'UP'
    if keys[pygame.K_DOWN] and playerSnake.direction != 'UP':
        playerSnake.direction = 'DOWN'

    
    if playerSnake.hitbox[1] < thing.hitbox[1] + thing.hitbox[3] and playerSnake.hitbox[1] + playerSnake.hitbox[3] > thing.hitbox[1]:
        if playerSnake.hitbox[0] + playerSnake.hitbox[2] > thing.hitbox[0] and playerSnake.hitbox[0] < thing.hitbox[0] + thing.hitbox[2]:
            thing.x2 = random.randrange(20, 760 - width2)
            thing.y2 = random.randrange(25, 750 - height2)
            playerSnake.width += 20
            score += 1
            snake_list.append([playerSnake.x, playerSnake.y])


    if playerSnake.x - playerSnake.vel <= 0:
        win.blit(textOVER, (400 - textOVER.get_width() / 2, 390 - textOVER.get_height() / 2))
        pygame.display.update()
        i = 0
        while i < 300:
            pygame.time.delay(10)
            i += 1
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    i = 301
                    pygame.quit()
        run = False
    if playerSnake.x + playerSnake.width + playerSnake.vel >= sirinaEkrana:
        win.blit(textOVER, (400 - textOVER.get_width() / 2, 390 - textOVER.get_height() / 2))
        pygame.display.update()
        i = 0
        while i < 300:
            pygame.time.delay(10)
            i += 1
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    i = 301
                    pygame.quit()
        run = False
    if playerSnake.y - playerSnake.vel <= 0:
        win.blit(textOVER, (400 - textOVER.get_width() / 2, 390 - textOVER.get_height() / 2))
        pygame.display.update()
        i = 0
        while i < 300:
            pygame.time.delay(10)
            i += 1
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    i = 301
                    pygame.quit()
        run = False
    if playerSnake.y + playerSnake.height + playerSnake.vel >= visinaEkrana:
        win.blit(textOVER, (400 - textOVER.get_width() / 2, 390 - textOVER.get_height() / 2))
        pygame.display.update()
        i = 0
        while i < 300:
            pygame.time.delay(10)
            i += 1
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    i = 301
                    pygame.quit()
        run = False

    redrawGameWindow()

pygame.quit()